-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 09, 2020 at 11:17 AM
-- Server version: 10.3.19-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booktrad_adv`
--

-- --------------------------------------------------------

--
-- Table structure for table `billboards`
--

CREATE TABLE `billboards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `region_id` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `billboards`
--

INSERT INTO `billboards` (`id`, `region_id`, `type`, `location`, `width`, `height`, `status`, `created_at`, `updated_at`, `path`) VALUES
(1, 1, 'کنار جاده ای', 'جنت آباد', 300, 100, 1, NULL, '2020-02-07 13:12:15', 'photos/7G26I14ebm6yUBBevmnGmHSGoQlnAZSweKoWlPd6.jpeg'),
(2, 1, 'کنار جاده ای', 'جنت آباد گلستان', 300, 100, 1, NULL, '2020-02-07 15:47:37', 'photos/NGtg4FBdlvHXaRM4JB1rHcNhk3Pf2V0vR1xnkgr4.jpeg'),
(3, 1, 'کنار جاده ای', 'جنت آباد گلستان بصارتی', 300, 100, 1, '2020-02-01 15:17:55', '2020-02-07 16:03:51', 'photos/clu9tsH7ABehz746MIiXlJREHmYY8jVbL82OyZAF.jpeg'),
(4, 3, 'بیلبورد عابر پیاده', 'اتوبان بابایی عرشه پل جاده لشگرک مسیر شرق به غرب', 200, 100, 1, '2020-02-07 12:34:43', '2020-02-07 12:50:09', 'photos/8tLQULuf8BtCyxvA6Qdy0NZq2Z5fQi83ragjnZzV.jpeg'),
(6, 4, 'پل جاده ای', 'اتوبان اشرفی اصفهانی عرشه پل تقاطع همت مسیر شمال به جنوب', 300, 100, 1, '2020-02-07 12:54:03', '2020-02-07 12:54:03', 'photos/W810WyCBFdPf7byGcwB00aPsbBu9eDoFY2A4kSq6.jpeg'),
(7, 4, 'بیلبورد عابر پیاده', 'اتوبان اشرفی اصفهانی بعد از اتوبان همت روبروی مجتمع حکیم عرشه پل عابر پیاده', 200, 100, 1, '2020-02-07 12:54:51', '2020-02-07 12:54:51', 'photos/Lm77T2NIUbzvoLJUjmi7Ax7MSbSzll4DMPgicptD.jpeg'),
(8, 5, 'بیلبورد عابر پیاده', 'آزاد راه تهران کرج عرشه پل کوهک مسیر غرب به شرق', 200, 100, 1, '2020-02-07 12:56:16', '2020-02-07 12:56:16', 'photos/DUYiB5toaXcFUpUlfQvOHFLl2GDJMMY8z5gFnzdM.jpeg'),
(9, 6, 'بیلبورد عابر پیاده', 'اتوبان چمران بعد از پل مدیریت عرشه پل عابر پیاده مسیر شمال به جنوب', 200, 100, 1, '2020-02-07 12:57:58', '2020-02-07 12:57:58', 'photos/yjRdoqR38CEHoa3RF2jVePUJQc5f6QP2PzjzmjCg.jpeg'),
(10, 7, 'بیلبورد عابر پیاده', 'اتوبان ستاری عرشه پل عابر پیاده قبل از کوروش مسیر جنوب به شمال', 200, 100, 1, '2020-02-07 12:59:26', '2020-02-07 12:59:26', 'photos/pnBHpPtJWGksWgmRfwHLrP5DgU4f7lXZrhUPZFkR.jpeg'),
(11, 8, 'پانل های دیواری', 'استرابورد آرژانتین خیابان بیهقی جنب فروشگاه شهروند', 100, 100, 1, '2020-02-07 13:26:03', '2020-02-07 13:26:03', 'photos/BCi684DaCiNlBhO0ykP0DV953KVQtgFD3HElrWeq.jpeg'),
(12, 9, 'پانل های دیواری', 'استرابورد اتوبان امام علی بعد از پل رسالت مسیر جنوب به شمال', 100, 100, 1, '2020-02-07 13:29:05', '2020-02-07 13:29:05', 'photos/qUFEwYtFJ0NtONl8PaG41LpPaIMnDQ7CN72ksulF.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `created_at`, `updated_at`) VALUES
(1, 'محمد', 'mohammadkakuei@gmail.com', 'sdfsdf', '2020-01-30 07:01:02', '2020-01-30 07:01:02'),
(2, 'محمد', 'mohammadkakuei@gmail.com', 'sdfds', '2020-01-30 07:02:25', '2020-01-30 07:02:25'),
(3, 'hhkj', 'mohammadkakuei@gmail.com', 'hj', '2020-01-30 07:02:55', '2020-01-30 07:02:55'),
(4, 'sdfsd', 'sdfds', 'sdfds', '2020-01-30 07:03:19', '2020-01-30 07:03:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(21, '2014_10_12_000000_create_users_table', 1),
(22, '2014_10_12_100000_create_password_resets_table', 1),
(23, '2019_08_19_000000_create_failed_jobs_table', 1),
(24, '2020_01_22_165608_create_bilboards_table', 1),
(25, '2020_01_28_064202_create_orders_table', 1),
(26, '2020_01_28_135204_create_regions_table', 1),
(27, '2020_01_29_081503_create_plans_table', 2),
(28, '2020_01_30_095625_create_messages_table', 3),
(29, '2020_01_30_121542_add_path_coloumn_to_bilboards_table', 4),
(30, '2020_02_01_163345_add_role_id_column_to_users_table', 5),
(31, '2020_02_07_213512_create_tickets_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `advertise_file_path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `billboard_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `start_time` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `end_time` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `plan_id`, `price`, `advertise_file_path`, `billboard_id`, `start_date`, `end_date`, `start_time`, `end_time`, `created_at`, `updated_at`) VALUES
(39, 7, 1, 550, 'photos/bmsHz6nrt4BfjFWMs2Fte11JLSrxfeu4h9ZJOCd3.jpeg', 2, '2020-02-01', '2020-02-12', NULL, NULL, '2020-02-03 14:14:32', '2020-02-03 14:14:32'),
(40, 1, 2, 3600, 'photos/GxBeKtZApDF7DFymDxrCKPlekIqEXs8H7XoGgxkW.jpeg', 1, '2020-02-01', '2020-02-19', NULL, NULL, '2020-02-03 18:28:25', '2020-02-03 18:28:25'),
(41, 1, 1, 2000, 'photos/04remxXXaZyIejA1zaOKyQvM1Etdr1U0XbDjAPs6.jpeg', 4, '2020-02-01', '2020-02-21', NULL, NULL, '2020-02-07 14:35:08', '2020-02-07 14:35:08'),
(42, 1, 1, 2600, 'photos/7SrlCI3oIy8NrR2Cy8NH4W7ABCqvBqpCdPFOR0nW.jpeg', 6, '2020-02-01', '2020-02-27', NULL, NULL, '2020-02-07 14:36:14', '2020-02-07 14:36:14'),
(43, 1, 1, 2700, 'photos/mZGYXhs59qdgJWjQ8TfLRt0qWYKmozspzUIwvHeJ.jpeg', 6, '2020-02-01', '2020-02-28', NULL, NULL, '2020-02-07 15:00:40', '2020-02-07 15:00:40'),
(44, 1, 3, 3900, 'photos/JlIblDNJuFyS7ErcpbgKYAqKfjS7JxFY17n8W821.jpeg', 6, '2020-02-01', '2020-02-14', NULL, NULL, '2020-02-07 17:21:21', '2020-02-07 17:21:21'),
(45, 1, 1, 1800, 'photos/wCf0j6JvfSYEvfItHS3qIH7O6tXlCx2Vx30Tt8OF.jpeg', 12, '2020-02-01', '2020-02-19', NULL, NULL, '2020-02-07 17:23:41', '2020-02-07 17:23:41'),
(46, 1, 2, 2200, 'photos/VeQ67YVKvjWu1CQsf3Wj4YAhFnvkAuCYruzH8Voq.jpeg', 11, '2020-02-01', '2020-02-12', NULL, NULL, '2020-02-07 17:27:09', '2020-02-07 17:27:09'),
(47, 1, 1, 2500, 'photos/ETfmm7hoD3CIyFXH7F4yaOtnEykEFk5UPWA6vzOW.jpeg', 4, '2020-02-01', '2020-02-26', NULL, NULL, '2020-02-08 14:38:11', '2020-02-08 14:38:11');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('mohammadkakuei@gmail.com', '$2y$10$hX/ie6teNhgz7eeavcRZI.G2fCu2FPmzk3/IRrq16hZ3Nh18crFeG', '2020-02-03 16:45:23');

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `name`, `price`, `created_at`, `updated_at`) VALUES
(1, 'اقتصادی', '100', NULL, '2020-02-07 16:17:17'),
(2, 'معمولی', '200', NULL, NULL),
(3, 'ویژه', '300', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `billboard_count` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`, `billboard_count`, `created_at`, `updated_at`) VALUES
(1, 'منطقه 5 جنت آباد', 50, NULL, NULL),
(2, 'منطقه 1 ولنجک', 10, NULL, NULL),
(3, 'اتوبان بابایی', 10, '2020-02-07 12:35:26', '2020-02-07 12:35:26'),
(4, 'اتوبان اشرفی', 10, '2020-02-07 12:53:24', '2020-02-07 12:53:24'),
(5, 'آزاد راه تهران کرج', 10, '2020-02-07 12:55:31', '2020-02-07 12:55:31'),
(6, 'اتوبان چمران', 10, '2020-02-07 12:57:01', '2020-02-07 12:57:01'),
(7, 'اتوبان ستاری', 10, '2020-02-07 12:58:42', '2020-02-07 12:58:42'),
(8, 'آزژانتین', 10, '2020-02-07 13:24:18', '2020-02-07 13:24:18'),
(9, 'اتوبان امام علی', 10, '2020-02-07 13:28:18', '2020-02-07 13:28:18');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `role_id` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `address`, `mobile`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `role_id`) VALUES
(1, 'محمد', 'تت', '09381957363', 'mohammadkakuei@gmail.com', NULL, '$2y$10$QSoKvTM1TV1qLupU6uKXQualZbs721/Z2YUkjRTmxRwG/tP2cv2oS', NULL, '2020-01-28 17:59:59', '2020-02-07 14:35:49', 0),
(3, 'علی حسینی', 'کرمان میدان جهاد', '09121111111', 'test2@test.com', NULL, '$2y$10$.JxuKet5fF1xPHUqke4wWeuoJeHUqkPvBjsj0YlF4ySz1bwUEkVWC', NULL, '2020-01-30 04:26:55', '2020-01-30 04:26:55', 0),
(5, 'ادمین', 'تهران میدان ونک کوچه 4', '09381957363', 'admin@test.com', NULL, '$2y$10$Pw/0SmynNeoicvXm9c/BseBfhCdiFmmi7YpUxyqWjndjgx.PulmdW', NULL, '2020-02-01 13:28:10', '2020-02-03 18:21:35', 1),
(6, 'علی احمدی', 'تهران میدان ونک کوچه 4', '09381957363', 'ali@ahmadi.com', NULL, '$2y$10$sQNTJKxU8Bc3cDrhdm9ViOsMJIf02cnFnqJXwjFhNS6upNP2rdHVK', NULL, '2020-02-02 11:26:40', '2020-02-02 11:26:40', 0),
(7, 'احمد ذوقی', 'همدان', '09381957363', 'ahmad@test.com', NULL, '$2y$10$iLFBwwPta681nvnj.GPsI.Bzan8eIaSKBlJd210zwfd9OETk8ED.a', NULL, '2020-02-03 14:13:41', '2020-02-03 14:13:41', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billboards`
--
ALTER TABLE `billboards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `billboards`
--
ALTER TABLE `billboards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
